package com.example.elizabeth_hodgman_inventorytracker;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import java.util.ArrayList;
import android.os.Bundle;

public class InventoryActivity extends AppCompatActivity {

    Button AddItemButton, TextSettingsButton;
    ListView ItemsListView;
    ItemDatabase db;
    static String Email, PhoneNum;
    ArrayList<Item> items;
    ItemList itemList;
    int itemCount;
    AlertDialog AlertDialog = null;

    public static final String UserEmail = "";
    private static final int USER_PERMISSION_SEND_SMS = 0;
    public static boolean textEnabled = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // Initiate variables
        AddItemButton = findViewById(R.id.AddNewItemButton);
        TextSettingsButton = findViewById(R.id.TextNotificationButton);
        ItemsListView = findViewById(R.id.InventoryList);
        db = new ItemDatabase(this);



        // Retrieve user's email and phone number from LoginActivity
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            Email = bundle.getString("email");
            PhoneNum = bundle.getString("phoneNum");
        }

        items = (ArrayList<Item>) db.GetAllItems();

        itemCount = db.getItemsCount();

        if (itemCount > 0) {
            itemList = new ItemList(this, items, db);
            ItemsListView.setAdapter(itemList);
        } else {
            Toast.makeText(this, "No Items in Inventory!", Toast.LENGTH_LONG).show();
        }

        // Activity launcher for AddItemButton listener
        ActivityResultLauncher<Intent> someActivityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        itemCount = db.getItemsCount();

                        if(itemList == null)	{
                            itemList = new ItemList(this, items, db);
                            ItemsListView.setAdapter(itemList);
                        }

                        itemList.items = (ArrayList<Item>) db.GetAllItems();
                        ((BaseAdapter)ItemsListView.getAdapter()).notifyDataSetChanged();
                    }else {
                        Toast.makeText(this, "Going Back", Toast.LENGTH_SHORT).show();
                    }
                });

        // Listener for AddItemButton
        AddItemButton.setOnClickListener(view -> {
            // Opens new AddItemActivity, pulls item over to InventoryActivity
            Intent addItem = new Intent(this, AddItemActivity.class);
            addItem.putExtra(UserEmail, Email);
            someActivityResultLauncher.launch(addItem);
        });

        // Listener for TextSettingsButton
        TextSettingsButton.setOnClickListener(view -> {
            // Looks for SMS permission, opens permission window for new users
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {

                if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                        Manifest.permission.SEND_SMS)) {
                    // If permission is denied, user will see this message
                    Toast.makeText(this,"Device SMS Permission is Needed", Toast.LENGTH_LONG).show();
                }
                else {
                    // Manifest an alert if permission is not found
                    ActivityCompat.requestPermissions(this,
                            new String[] {Manifest.permission.SEND_SMS},
                            USER_PERMISSION_SEND_SMS);
                }
            }
            else {
                // If permission is allowed, user will see this message
                Toast.makeText(this,"Device SMS Permission is Allowed", Toast.LENGTH_LONG).show();
            }

            // Open SMS Permission Alert Dialog
            AlertDialog = SMSNotification.doubleButton(this);
            AlertDialog.show();
        });
    }

    // Setting Logout item in AppBar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add("Logout"); //only one menu item
        return super.onCreateOptionsMenu(menu);
    }

    // Logout user
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getTitle() == "Logout") {
            // End ItemsListActivity on menu item click.
            db.close();
            super.finish();
            Toast.makeText(this,"Logout Successful", Toast.LENGTH_LONG).show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // Change textEnabled depending on the users response from SMSNotification
    public static void EnableTexts() {
        textEnabled = true;
    }

    public static void DisableTexts() {
        textEnabled = false;
    }

    public static void SendSMSMessage(Context context) {
        String userNum = PhoneNum;
        String textMessage = "Oh no! An item's quantity has reached zero in your Inventory Tracker App!";

        // Evaluate AlertDialog permission to send SMS and ItemQtyValue value
        if (textEnabled) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(userNum, null, textMessage, null, null);
                Toast.makeText(context, "Text Sent!", Toast.LENGTH_LONG).show();
            } catch (Exception ex) {
                Toast.makeText(context, "Device Permission Denied", Toast.LENGTH_LONG).show();
                ex.printStackTrace();
            }
        } else {
            Toast.makeText(context, "Text Notifications Disabled", Toast.LENGTH_LONG).show();
        }
    }
}