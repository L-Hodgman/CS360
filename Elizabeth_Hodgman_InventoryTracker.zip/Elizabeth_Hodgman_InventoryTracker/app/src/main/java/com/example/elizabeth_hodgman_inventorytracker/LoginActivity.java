package com.example.elizabeth_hodgman_inventorytracker;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    Activity activity;
    Button LoginBtn, RegisterBtn;
    EditText LoginEmail, LoginPassword;
    String Email, Password, PhoneNum;
    Boolean EmptyEditText;
    SQLiteDatabase db;
    UserDatabase handler;
    String TempPassword = "NOT_FOUND";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        activity = this;

        LoginBtn = findViewById(R.id.LoginButton);
        RegisterBtn = findViewById(R.id.RegisterButton);
        LoginEmail = findViewById(R.id.UserLoginEmail);
        LoginPassword = findViewById(R.id.UserLoginPassword);
        handler = new UserDatabase(this);

        // Listener for LoginBtn
        LoginBtn.setOnClickListener(view -> {
            // Call Login function
            Login();
        });

        // Listener for RegisterBtn
        RegisterBtn.setOnClickListener(view -> {
            // Opening new RegisterActivity
            Intent intent = new Intent(LoginActivity.this, RegisterNewAccount.class);
            startActivity(intent);
        });
    }


    // Login function
    @SuppressLint("Range")
    public void Login() {
        String message = CheckEditTextNotEmpty();

        if(!EmptyEditText) {
            // Opening SQLite database
            db = handler.getWritableDatabase();

            // Adding email to cursor
            Cursor cursor = db.query(UserDatabase.TABLE_NAME, null, " " + UserDatabase.COLUMN_2_EMAIL + "=?", new String[]{Email}, null, null, null);

            while (cursor.moveToNext()) {
                if (cursor.isFirst()) {
                    cursor.moveToFirst();

                    // Storing Password and Phone Number associated with entered email
                    TempPassword = cursor.getString(cursor.getColumnIndex(UserDatabase.COLUMN_3_PASSWORD));
                    PhoneNum = cursor.getString(cursor.getColumnIndex(UserDatabase.COLUMN_1_PHONE_NUMBER));

                    // Close cursor
                    cursor.close();
                }
            }
            handler.close();

            // Check final result
            CheckLoginFinalResult();
        } else {
            // If any inputs are empty then will display message from CheckEditTextNotEmpty
            Toast.makeText(LoginActivity.this, message, Toast.LENGTH_LONG).show();
        }
    }

    // Check if any EditTexts are empty
    public String CheckEditTextNotEmpty() {
        // Store data as strings
        String message = "";
        Email = LoginEmail.getText().toString().trim();
        Password = LoginPassword.getText().toString().trim();

        if (Email.isEmpty()){
            LoginEmail.requestFocus();
            EmptyEditText = true;
            message = "User Email is Empty";
        } else if (Password.isEmpty()){
            LoginPassword.requestFocus();
            EmptyEditText = true;
            message = "User Password is Empty";
        } else {
            EmptyEditText = false;
        }
        return message;
    }

    // Check if password is associated with email in database
    public void CheckLoginFinalResult(){
        if(TempPassword.equalsIgnoreCase(Password)) {
            Toast.makeText(LoginActivity.this,"Login Successful",Toast.LENGTH_SHORT).show();

            // Send user data to InventoryActivity
            Bundle bundle = new Bundle();
            bundle.putString("email", Email);
            bundle.putString("phoneNum", PhoneNum);

            // Go to InventoryActivity
            Intent intent = new Intent(LoginActivity.this, InventoryActivity.class);
            intent.putExtras(bundle);
            startActivity(intent);

            // Empty EditText
            EmptyEditTextAfterDataInsert();
        } else {
            // Show error message if incorrect credentials are inputted
            Toast.makeText(LoginActivity.this,"Please Check that the Email and Password are Correct\nor Create a New Account",Toast.LENGTH_LONG).show();
        }
        TempPassword = "NOT_FOUND" ;
    }

    // Empty EditText
    public void EmptyEditTextAfterDataInsert(){
        LoginEmail.getText().clear();
        LoginPassword.getText().clear();
    }

}