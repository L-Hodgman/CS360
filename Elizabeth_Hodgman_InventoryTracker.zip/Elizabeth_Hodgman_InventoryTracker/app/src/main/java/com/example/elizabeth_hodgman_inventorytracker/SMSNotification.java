package com.example.elizabeth_hodgman_inventorytracker;

import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

public class SMSNotification {
    public static AlertDialog doubleButton(final InventoryActivity context){
        // Build dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(R.string.sms_alert_title)
                .setCancelable(false)
                .setMessage(R.string.sms_alert)
                .setPositiveButton(R.string.sms_enable_button, (dialog, arg1) -> {
                    // Texts Enabled
                    Toast.makeText(context, "Text Alerts Enabled", Toast.LENGTH_LONG).show();
                    InventoryActivity.EnableTexts();
                    dialog.cancel();
                })
                .setNegativeButton(R.string.sms_disable_button, (dialog, arg1) -> {
                    // Texts Disabled
                    Toast.makeText(context, "Text Alerts Disabled", Toast.LENGTH_LONG).show();
                    InventoryActivity.DisableTexts();
                    dialog.cancel();
                });

        // Create the AlertDialog
        return builder.create();
    }
}
