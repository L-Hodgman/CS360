package com.example.elizabeth_hodgman_inventorytracker;

public class Item {
    int id;
    String email;
    String description;
    String quantity;

    public Item() {
        super();
    }

    // constructor
    public Item(String userEmail, String itemDesc, String itemQty) {
        this.email = userEmail;
        this.description = itemDesc;
        this.quantity = itemQty;
    }

    public int getId() {

        return id;
    }

    public void setId(int id) {

        this.id = id;
    }

    public String getUserEmail() {

        return email;
    }

    public void setUserEmail(String email) {

        this.email = email;
    }

    public String getDescription() {

        return description;
    }

    public void setDescription(String description) {

        this.description = description;
    }

    public String getQuantity() {

        return quantity;
    }

    public void setQuantity(String quantity) {

        this.quantity = quantity;
    }
}
