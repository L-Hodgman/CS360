package com.example.elizabeth_hodgman_inventorytracker;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterNewAccount extends AppCompatActivity {

    Activity activity;
    Button CancelBtn, CreateAcctBtn;
    EditText Email, Password, PhoneNum;
    Boolean EmptyEditText;
    SQLiteDatabase db;
    UserDatabase handler;
    String EmailSearch = "NOT_FOUND";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_new_account);
        activity = this;

        CancelBtn = findViewById(R.id.CancelCreateAcctButton);
        CreateAcctBtn = findViewById(R.id.CreateAccountButton);
        Email = findViewById(R.id.UserLoginEmail);
        Password = findViewById(R.id.UserLoginPassword);
        PhoneNum = findViewById(R.id.UserPhoneNumber);
        handler = new UserDatabase(this);


        CreateAcctBtn.setOnClickListener(view -> {
            String message = CheckEditTextNotEmpty();

            if (!EmptyEditText) {
                // Check if email is already in use
                CheckEmailAlreadyExists();
                // Clear user info from EditTexts
                ClearUserInfo();
            } else {
                // Show message if any EditTexts are empty
                Toast.makeText(this, message, Toast.LENGTH_LONG).show();
            }
        });

        // Listener to CancelBtn
        CancelBtn.setOnClickListener(view -> {
            // Go back to LoginActivity
            startActivity(new Intent(RegisterNewAccount.this, LoginActivity.class));
            this.finish();
        });
    }

    // Check if EditTexts are empty
    public String CheckEditTextNotEmpty() {
        // Store values as strings
        String message = "";
        String email = Email.getText().toString().trim();
        String password = Password.getText().toString().trim();
        String phone = PhoneNum.getText().toString().trim();

        if (email.isEmpty()){
            Email.requestFocus();
            EmptyEditText = true;
            message = "User Email is Empty";
        } else if (password.isEmpty()){
            Password.requestFocus();
            EmptyEditText = true;
            message = "User Password is Empty";
        } else if (phone.isEmpty()) {
            PhoneNum.requestFocus();
            EmptyEditText = true;
            message = "User Phone Number is Empty";
        }else {
            EmptyEditText = false;
        }
        return message;
    }

    // Register new user
    public void RegisterUser(){
        String email = Email.getText().toString().trim();
        String pass = Password.getText().toString().trim();
        String phone = PhoneNum.getText().toString().trim();

        User user = new User(phone, email, pass);
        handler.createUser(user);

        // Show message when account is registered
        Toast.makeText(RegisterNewAccount.this,"User Registered Successfully!\nPlease Login", Toast.LENGTH_LONG).show();

        // Go back to LoginActivity
        startActivity(new Intent(RegisterNewAccount.this, LoginActivity.class));
        this.finish();
    }

    // Check if email is already in use
    public void CheckEmailAlreadyExists(){
        String email = Email.getText().toString().trim();
        db = handler.getWritableDatabase();

        // Adding search email query to cursor
        Cursor cursor = db.query(UserDatabase.TABLE_NAME, null, " " + UserDatabase.COLUMN_2_EMAIL + "=?", new String[]{email}, null, null, null);

        while (cursor.moveToNext()) {
            if (cursor.isFirst()) {
                cursor.moveToFirst();
                // If email exists then set result variable
                EmailSearch = "Email Found";
                // Closing cursor.
                cursor.close();
            }
        }
        handler.close();

        // Check final result and add user to database
        CheckRegisterInfo();
    }

    // Check register information
    public void CheckRegisterInfo(){
        // Check if email is in database
        if(EmailSearch.equalsIgnoreCase("Email Found"))
        {
            // If email is in database - then show message
            Toast.makeText(RegisterNewAccount.this,"Email Already in Use",Toast.LENGTH_LONG).show();
        }
        else {
            // Add user to database if new email is used
            RegisterUser();
        }
        EmailSearch = "Not_Found" ;
    }

    // Empty EditText
    public void ClearUserInfo(){
        Email.getText().clear();
        Password.getText().clear();
        PhoneNum.getText().clear();
    }

}