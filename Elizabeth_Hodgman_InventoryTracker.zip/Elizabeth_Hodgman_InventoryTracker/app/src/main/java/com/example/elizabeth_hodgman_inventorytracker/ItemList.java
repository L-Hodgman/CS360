package com.example.elizabeth_hodgman_inventorytracker;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;

public class ItemList extends BaseAdapter {
    private final Activity context;
    ArrayList<Item> items;
    ItemDatabase db;

    public ItemList(Activity context, ArrayList<Item> items, ItemDatabase db) {
        this.context = context;
        this.items = items;
        this.db = db;
    }

    public static class ViewHolder {
        TextView textViewItemDesc;
        TextView textViewItemQty;
        ImageButton increaseBtn;
        ImageButton decreaseBtn;
        ImageButton deleteBtn;
    }

    @SuppressLint("InflateParams")
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView;
        LayoutInflater inflater = context.getLayoutInflater();
        ViewHolder vh;

        if (convertView == null) {
            vh = new ViewHolder();
            row = inflater.inflate(R.layout.list_template, null, true);

            vh.textViewItemDesc = row.findViewById(R.id.ItemPlacement);
            vh.textViewItemQty = row.findViewById(R.id.QuantityPlacement);
            vh.increaseBtn = row.findViewById(R.id.IncreaseButton);
            vh.decreaseBtn = row.findViewById(R.id.DecreaseButton);
            vh.deleteBtn = row.findViewById(R.id.DeleteButton);

            row.setTag(vh);
        } else {
            vh = (ViewHolder) convertView.getTag();
        }

        vh.textViewItemDesc.setText(items.get(position).getDescription());
        vh.textViewItemQty.setText(items.get(position).getQuantity());

        // Check if the item quantity is zero - then change color and send text
        String value = vh.textViewItemQty.getText().toString().trim();
        if (value.equals("0")) {
            // Change background color and text color of item description and qty cells if value is zero
            vh.textViewItemQty.setBackgroundColor(Color.RED);
            vh.textViewItemQty.setTextColor(Color.WHITE);
            vh.textViewItemDesc.setBackgroundColor(Color.RED);
            vh.textViewItemDesc.setTextColor(Color.WHITE);
            InventoryActivity.SendSMSMessage(context.getApplicationContext());
        } else {
            // Change background color and text color of item description and qty cells to default
            vh.textViewItemQty.setBackgroundColor(Color.parseColor("#E6E6E6"));
            vh.textViewItemQty.setTextColor(Color.BLACK);
            vh.textViewItemDesc.setBackgroundColor(Color.parseColor("#E6E6E6"));
            vh.textViewItemDesc.setTextColor(Color.BLACK);
        }

        final int positionPopup = position;

        // UP Arrow
        vh.increaseBtn.setOnClickListener(view -> {
            db.IncreaseQuantity(items.get(positionPopup));

            items = (ArrayList<Item>) db.GetAllItems();
            notifyDataSetChanged();
        });

        // DOWN Arrow
        vh.decreaseBtn.setOnClickListener(view -> {
            db.DecreaseQuantity(items.get(positionPopup));

            items = (ArrayList<Item>) db.GetAllItems();
            notifyDataSetChanged();
        });

        // Garbage Can
        vh.deleteBtn.setOnClickListener(view -> {
            db.DeleteItem(items.get(positionPopup));

            items = (ArrayList<Item>) db.GetAllItems();
            notifyDataSetChanged();

            Toast.makeText(context, "Item Deleted", Toast.LENGTH_SHORT).show();
        });

        return  row;
    }

    public Object getItem(int position) {
        return position;
    }

    public long getItemId(int position) {
        return position;
    }

    public int getCount() {
        return items.size();
    }

}
