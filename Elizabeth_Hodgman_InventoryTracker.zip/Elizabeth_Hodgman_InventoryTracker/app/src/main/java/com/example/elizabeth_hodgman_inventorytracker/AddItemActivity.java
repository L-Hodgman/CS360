package com.example.elizabeth_hodgman_inventorytracker;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.concurrent.atomic.AtomicReference;

public class AddItemActivity extends AppCompatActivity {

    String Email, Desc, Qty;
    EditText ItemDescValue, ItemQtyValue;
    Button CancelButton, AddItemButton;
    Boolean EmptyEditText;
    ItemDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        // Initiate variables
        ItemDescValue = findViewById(R.id.NewItemDescription);
        ItemQtyValue = findViewById(R.id.NewItemQuantity);
        CancelButton = findViewById(R.id.CancelButton);
        AddItemButton = findViewById(R.id.AddItemButton);
        db = new ItemDatabase(this);

        AtomicReference<Intent> intent = new AtomicReference<>(getIntent());

        // Receive user email from InventoryActivity
        Email = intent.get().getStringExtra(InventoryActivity.UserEmail);

        // Listener for CancelButton
        CancelButton.setOnClickListener(view -> {
            // Go back to InventoryActivity
            Intent add = new Intent();
            setResult(0, add);
            this.finish();
        });

        // Listener for AddItemButton and move data to InventoryActivity
        AddItemButton.setOnClickListener(view -> AddItem());
    }

    // Store item into database and send data to InventoryActivity
    public void AddItem() {
        String message = CheckEditTextNotEmpty();

        if (!EmptyEditText) {
            String email = Email;
            String desc = Desc;
            String qty = Qty;

            Item item = new Item(email, desc, qty);
            db.CreateItem(item);

            // Show message if item is added
            Toast.makeText(this,"New Item Added!", Toast.LENGTH_LONG).show();

            // Close AddItemActivity
            Intent add = new Intent();
            setResult(RESULT_OK, add);
            this.finish();
        } else {
            // Show message if description or quantity is empty
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        }
    }

    // Checking item description and quantity is not empty
    public String CheckEditTextNotEmpty() {
        // Getting inputs from EditTexts and storing as a string
        String message = "";
        Desc = ItemDescValue.getText().toString().trim();
        Qty = ItemQtyValue.getText().toString().trim();

        if (Desc.isEmpty()) {
            ItemDescValue.requestFocus();
            EmptyEditText = true;
            message = "Item Description is Empty";
        } else if (Qty.isEmpty()){
            ItemQtyValue.requestFocus();
            EmptyEditText = true;
            message = "Item Quantity is Empty";
        } else {
            EmptyEditText = false;
        }
        return message;
    }
}