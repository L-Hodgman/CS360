package com.example.elizabeth_hodgman_inventorytracker;

public class User {
    int id;
    String phoneNum;
    String email;
    String password;

    public User(String userPhoneNum, String userEmail, String userPass) {
        this.phoneNum = userPhoneNum;
        this.email = userEmail;
        this.password = userPass;
    }

    public int getId() {

        return id;
    }

    // Getters for phone number, email, and password
    public String getUserPhone() {

        return phoneNum;
    }

    public String getUserEmail() {

        return email;
    }

    public String getUserPass() {

        return password;
    }

}