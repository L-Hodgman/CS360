package com.example.elizabeth_hodgman_inventorytracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;


public class UserDatabase extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;

    private static final String DATABASE_NAME = "UserDatabase.DB";
    public static final String TABLE_NAME = "UsersTable";

    public static final String COLUMN_0_ID = "id";
    public static final String COLUMN_1_PHONE_NUMBER = "phone_number";
    public static final String COLUMN_2_EMAIL = "email";
    public static final String COLUMN_3_PASSWORD = "password";

    private static final String CREATE_USERS_TABLE = "CREATE TABLE IF NOT EXISTS " +
            TABLE_NAME + " (" +
            COLUMN_0_ID + " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
            COLUMN_1_PHONE_NUMBER + " VARCHAR, " +
            COLUMN_2_EMAIL + " VARCHAR, " +
            COLUMN_3_PASSWORD + " VARCHAR" + ")";

    public UserDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase database) {
        database.execSQL(CREATE_USERS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // Add user to database
    public void createUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_1_PHONE_NUMBER, user.getUserPhone());
        values.put(COLUMN_2_EMAIL, user.getUserEmail());
        values.put(COLUMN_3_PASSWORD, user.getUserPass());

        db.insert(TABLE_NAME, null, values);
        db.close();
    }

}
