package com.example.elizabeth_hodgman_inventorytracker;

import android.content.Context;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class ItemDatabase extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;

    private static final String DATABASE_NAME = "ItemData.DB";
    private static final String TABLE_NAME = "ItemsTable";

    private static final String COLUMN_0_ID = "id";
    private static final String COLUMN_1_USER_EMAIL = "email";
    private static final String COLUMN_2_DESCRIPTION = "description";
    private static final String COLUMN_3_QUANTITY = "quantity";

    private static final String CREATE_ITEMS_TABLE = "CREATE TABLE IF NOT EXISTS " +
            TABLE_NAME + " (" +
            COLUMN_0_ID + " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
            COLUMN_1_USER_EMAIL + " VARCHAR, " +
            COLUMN_2_DESCRIPTION + " VARCHAR, " +
            COLUMN_3_QUANTITY + " VARCHAR " + ");";

    public ItemDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_ITEMS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // Add item to database
    public void CreateItem(Item item) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_1_USER_EMAIL, item.getUserEmail());
        values.put(COLUMN_2_DESCRIPTION, item.getDescription());
        values.put(COLUMN_3_QUANTITY, item.getQuantity());

        db.insert(TABLE_NAME, null, values);
        db.close();
    }

    // Update item in database
    public void UpdateItem(Item item) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_1_USER_EMAIL, item.getUserEmail());
        values.put(COLUMN_2_DESCRIPTION, item.getDescription());
        values.put(COLUMN_3_QUANTITY, item.getQuantity());

        db.update(TABLE_NAME, values, COLUMN_0_ID + " = ?", new String[]{String.valueOf(item.getId())});
    }

    // Increase item quantity by pressing "UP" arrow
    public void IncreaseQuantity(Item item) {
        int input, total;

        String qty = item.getQuantity();

        input = Integer.parseInt(qty);
        total = input + 1;
        item.setQuantity(String.valueOf(total));
        UpdateItem(item);
    }

    // Increase item quantity by pressing "DOWN" arrow
    public void DecreaseQuantity(Item item) {
        int input, total;

        String qty = item.getQuantity();

        input = Integer.parseInt(qty);
        total = input - 1;
        item.setQuantity(String.valueOf(total));
        UpdateItem(item);
    }

    // Delete item by pressing garbage can
    public void DeleteItem(Item item) {
        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(TABLE_NAME, COLUMN_0_ID + " = ?", new String[] { String.valueOf(item.getId()) });
        db.close();
    }

    // Getting All Items
    public List<Item> GetAllItems() {
        List<Item> itemList = new ArrayList<>();

        // Select All Query
        String selectQuery = "SELECT * FROM " + TABLE_NAME;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // Loop through all the rows and add items to list
        if (cursor.moveToFirst()) {
            do {
                Item item = new Item();
                item.setId(Integer.parseInt(cursor.getString(0)));
                item.setUserEmail(cursor.getString(1));
                item.setDescription(cursor.getString(2));
                item.setQuantity(cursor.getString(3));

                itemList.add(item);
            } while (cursor.moveToNext());
        }

        cursor.close();

        return itemList;
    }

    // Get Items Count
    public int getItemsCount() {
        String countQuery = "SELECT * FROM " + TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        int itemsTotal = cursor.getCount();
        cursor.close();

        return itemsTotal;
    }
}
